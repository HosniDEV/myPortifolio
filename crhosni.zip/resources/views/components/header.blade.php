<header class="bg-secondColor  py-1  px-3 m:py-2 max-w-5xl md:mx-auto flex justify-between items-center">
   <img src="{{asset('images/6.png')}}" alt="loading" loading=lazy srcset="" class=" h-[40px] w-[40px] md:h-[50px] md:w-[50px]">
<div>
    <strong class=" text-lg md:text-xl font-bold text-red-600 tracking-wider font-instgram">HOSNIDEV</strong>
</div>
</header>
