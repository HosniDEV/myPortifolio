
<div class="flex space-x-3 items-baseline">
    <i class="fa fa-check-circle text-lg text-red-600" aria-hidden="true"></i>
    <div class="flex flex-col items-start">
        <h1 class="text-lg font-medium ">{{$title}}</h1>
        <p class="text-base font-normal text-gray-600">{{$slot}}</p>
    </div>
</div>
