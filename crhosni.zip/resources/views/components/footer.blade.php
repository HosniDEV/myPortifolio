<footer class="py-5 px-20 bg-gray-300 ">
   <x-container>
   <div class="flex flex-col items-center md:flex-row md:justify-between md:items-center">
    <p class="text-base font-medium text-center">Copyright {{now()->format('Y')}}. All rights reserved.</p>
    <x-social-media></x-social-media>
   </div>
   </x-container>
</footer>
