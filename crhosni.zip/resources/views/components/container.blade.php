<div class="max-w-5xl mx-auto">
    {{$slot}}
</div>
