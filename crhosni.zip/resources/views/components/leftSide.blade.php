<div class="  col-span-2 md:col-span-1  sticky top-20 ">
    <img src="{{asset('images/profil.jpg ')}}" alt="" srcset="" class="rounded-xl mb-1 relative hover:scale-95 duration-500 ease-in cursor-pointer w-full">
    <div class="absolute w-[2px] bg-red-600 h-[100px] -left-2 -top-2">

    </div>
    <div class="absolute h-[2px] bg-red-600 w-[100px] -top-2 -left-2">

    </div>
    <div class="absolute w-[2px] bg-primaryColor h-[100px] -left-4 -top-4">

    </div>
    <div class="absolute h-[2px] bg-primaryColor w-[100px] -top-4 -left-4">

    </div>

    <div class="flex justify-between items-center space-x-4 pl-2 md:pl-0">
     <h1 class=" font-bold text-lg ">HOSNI ABDELLAH</h1>
     <span class="h-[2px] bg-red-600 flex-grow "></span>
    </div>
    <h1 class="  font-medium  text-base pl-2 md:pl-0">Full stack developer & designer </h1>
 <x-social-media></x-social-media>
  </div>
