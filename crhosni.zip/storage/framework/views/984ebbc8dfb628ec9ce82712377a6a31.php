<div class="  col-span-2 md:col-span-1  sticky top-20 ">
    <img src="<?php echo e(asset('images/profil.jpg ')); ?>" alt="" srcset="" class="rounded-xl mb-1 relative hover:scale-95 duration-500 ease-in cursor-pointer w-full">
    <div class="absolute w-[2px] bg-red-600 h-[100px] -left-2 -top-2">

    </div>
    <div class="absolute h-[2px] bg-red-600 w-[100px] -top-2 -left-2">

    </div>
    <div class="absolute w-[2px] bg-primaryColor h-[100px] -left-4 -top-4">

    </div>
    <div class="absolute h-[2px] bg-primaryColor w-[100px] -top-4 -left-4">

    </div>

    <div class="flex justify-between items-center space-x-4 pl-2 md:pl-0">
     <h1 class=" font-bold text-lg ">HOSNI ABDELLAH</h1>
     <span class="h-[2px] bg-red-600 flex-grow "></span>
    </div>
    <h1 class="  font-medium  text-base pl-2 md:pl-0">Full stack developer & designer </h1>
 <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.social-media','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('social-media'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
  </div>
<?php /**PATH C:\Users\pc\Desktop\LaravelProjects\myPortifolio\resources\views/components/leftSide.blade.php ENDPATH**/ ?>