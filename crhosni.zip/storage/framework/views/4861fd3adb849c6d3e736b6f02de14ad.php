
<div class="flex space-x-3 items-baseline">
    <i class="fa fa-check-circle text-lg text-red-600" aria-hidden="true"></i>
    <div class="flex flex-col items-start">
        <h1 class="text-lg font-medium "><?php echo e($title); ?></h1>
        <p class="text-base font-normal text-gray-600"><?php echo e($slot); ?></p>
    </div>
</div>
<?php /**PATH C:\Users\pc\Desktop\LaravelProjects\myPortifolio\resources\views/components/card-project.blade.php ENDPATH**/ ?>