<svg fill="" viewBox="0 0 1695 57" class="fill-gray-200 "><path d="M0 23c135.4 19 289.6 28.5 462.5 28.5C721.9 51.5 936.7 1 1212.2 1c183.6-.1 344.5 7.3 482.8 22v34H0V23z"></path></svg>
    <div class=" bg-gray-200 relative ">
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.container','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
              <div class="py-6  px-2 md:py-12 flex justify-center items-center ">
        <div class=" flex flex-col items-center ">
         <div class="absolute right-0 bottom-0">
             <img src="<?php echo e(asset('images/5.png')); ?>" alt="" class="w-[300px]">
         </div>
         <div class="absolute left-0 -top-3">
             <img src="<?php echo e(asset('images/5.png')); ?>" alt="" class="w-[300px] -rotate-180">
         </div>
         <h1 class="text-3xl font-bold text-red-600  mb-3">Hit me up</h1>

         <form action="<?php echo e(route('post.store')); ?>" method="post" class="w-full  mt-3 ">
            <?php echo csrf_field(); ?>
      <div class="flex gap-3">
        <input required  name='name'type="text" class="px-3 py-2 outline-none w-full rounded-sm border border-red-600  bg-slate-200" placeholder="Full name">
        <input required name='email' type="email" class="px-3 py-2 outline-none w-full rounded-sm border border-red-600  bg-slate-200" placeholder="Your email adresse">
      </div>
      <div class="flex gap-3 mt-3 ">
        <textarea required  name='content'type="text" class="px-3 py-2 outline-none w-full rounded-sm border border-red-600  bg-slate-200" placeholder="what's on your mind"> </textarea>
      </div>
      <button type="submit" class="px-3 py-2 outline-none w-full rounded-sm border border-red-600  bg-red-600 mt-3 text-base font-medium text-white hover:bg-red-500" >Send</button>
        </div>
     </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>
    
    
<?php /**PATH C:\Users\pc\Desktop\LaravelProjects\myPortifolio\resources\views/components/newsletter.blade.php ENDPATH**/ ?>