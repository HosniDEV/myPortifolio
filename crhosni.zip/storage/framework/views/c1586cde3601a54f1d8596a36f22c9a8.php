<div class="max-w-5xl mx-auto">
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\pc\Desktop\LaravelProjects\myPortifolio\resources\views/components/container.blade.php ENDPATH**/ ?>